﻿using System;
namespace Carter_Jmarcus_Data_Practice
{
    public class Restaurant
    {
        // These are properties that assign value

        public string id { get; set; }
        public string restaurantName { get; set; }
        public string Address { get; set; }
        public string Phone { get; set; }
        public string HoursOfOperation { get; set; }
        public string Price { get; set; }
        public string USACityLocation { get; set; }
        public string Cuisine { get; set; }
        public string FoodRating { get; set; }
        public string ServiceRating { get; set; }
        public string AmbienceRating { get; set; }
        public string ValueRating { get; set; }
        public string OverallRating { get; set; }
        public string OverallPossibleRating { get; set; }
        public Restaurant(string i, string r, string a, string p, string h, string price, string usa, string c, string f, string s, string ambience, string v, string overall, string overallpossible)
        {
            // This code is assigning the parameters in the constructor to the properties. 
            id = i;
            restaurantName = r;
            Address = a;
            Phone = p;
            HoursOfOperation = h;
            Price = price;
            USACityLocation = usa;
            Cuisine = c;
            FoodRating = f;
            ServiceRating = s;
            AmbienceRating = ambience;
            ValueRating = v;
            OverallRating = overall;
            OverallPossibleRating = overallpossible;




        }
    }
}
