﻿using System;

namespace Carter_Jmarcus_Data_Practice
{
    class Program
    {
        static void Main(string[] args)
        {
            Assignment assignment = new Assignment();
        }
    }
}
