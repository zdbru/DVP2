﻿using System;
using System.IO;
using System.Collections.Generic;
using MySql.Data.MySqlClient;
namespace Carter_Jmarcus_Data_Practice
{
    public class External
    {
        public string Rating(decimal incomingRating)
        {
            string rating = "";
            if (rating == "5")
            {
                //Console.ForegroundColor = ConsoleColor.Green;
                return "*****";
            }
            else if (rating == "4")
            {
                //Console.ForegroundColor = ConsoleColor.Green;
                return "****";
            }
            else if (rating == "3")
            {
                //Console.ForegroundColor = ConsoleColor.Yellow;
                return "***";
            }
            else if (rating == "2")
            {
                //Console.ForegroundColor = ConsoleColor.Red;
                return "**";
            }
            else if (rating == "1")
            {
                //Console.ForegroundColor = ConsoleColor.Red;
                return "*";
            }
            else
            {
                if (rating == null)
                {
                    Console.ForegroundColor = ConsoleColor.Red;
                }
                return "Unrated";
            }
        }
       
    }  
}
