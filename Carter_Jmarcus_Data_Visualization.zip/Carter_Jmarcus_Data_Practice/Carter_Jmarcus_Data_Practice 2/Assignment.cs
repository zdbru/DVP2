﻿using System;
using System.IO;
using System.Collections.Generic;
using MySql.Data.MySqlClient;

namespace Carter_Jmarcus_Data_Practice
{
    public class Assignment
    {
        
        // These are my private fields that the whole class can access
        private Menu _mymenu;
        private List<Restaurant> _restaurant = new List<Restaurant>();
        private string _directory = @"../../output/";
        private string _filename = "Carter_Jmarcus_Converted_JSON";

        public Assignment()
        {
            Console.BackgroundColor = ConsoleColor.DarkGray;

            // this displays the menu
            _mymenu = new Menu("Convert From SQL To JSON", "Show 5 Star Rating System", "Show Animated Bar Graph Review System", "Play A Card Game", "Exit");
            _mymenu.Title = "Come Eat At This Fancy Restaurant";
            _mymenu.Display();
            Data();
            Selection();

        }
        // This method is the selection method that let the user make a selection in the menu
        private void Selection()
        {
            Console.BackgroundColor = ConsoleColor.DarkGray;
            int choice = Validation.ValidateInt("Welcome to our restaurant. Make a selection: ");
            switch (choice)
            {
                case 1:
                    Convert();
                    Continue();
                    break;
                case 2:
                    FiveStarRating();
                    Continue();
                    break;
                case 3:
                    AnimatedBar();
                    Continue();
                    break;
                case 4:
                    CardGame();
                    Continue();
                    break;
                case 5:
                    Console.WriteLine("Thank you for helping our restaurant . Hope you come by again.");
                    break;
                default:
                    Console.WriteLine("Please enter valid input.");
                    Continue();
                    break;
            }
        }
        private void Selection3()
        {
            Console.BackgroundColor = ConsoleColor.DarkGray;

            _mymenu = new Menu("Show the Best (5 Stars)", "Show 4 Stars and Up", "Show 3 Stars and Up", "Show the Worst (1 Stars)", "Show Unrated", "Back");
            _mymenu.Title = "Come Eat At This Fancy Restaurant";
            _mymenu.Display();

            int choice = Validation.ValidateInt("Hello Admin, How would you like to sort the data:");
            switch (choice)
            {
                case 1:
                    OnlyFiveStar();
                    Continue3();
                    break;
                case 2:
                    Over4();
                    Continue3();
                    break;
                case 3:
                    Over3();
                    Continue3();
                    break;
                case 4:
                    OneAndOnly();
                    Continue3();
                    break;
                case 5:

                    break;
                case 6:
                    BackToMenu();
                    break;
                default:
                    Continue();
                    break;
            }
        }
        private void Selection4()
        {
            Console.BackgroundColor = ConsoleColor.DarkGray;

            _mymenu = new Menu(" Show Average of Reviews for Restaurants", "Dinner Spinner (Selects Random Restaurant)", " Top 10 Restaurants", "Back To Main Menu");
            _mymenu.Title = "Come Eat At This Fancy Restaurant";
            _mymenu.Display();

            int choice = Validation.ValidateInt("Hello Admin, How would you like to sort the data:");
            switch (choice)
            {
                case 1:
                    Reviews();

                    break;
                case 2:
                    DinDin();
                    break;
                case 3:
                    Tops();
                    break;
                case 4:
                    BackToMenu();
                    break;
                default:
                    Console.WriteLine("Please enter valid input.");
                    Continue();
                    break;
            }
        }
        private void Selection2()
        {
            Console.BackgroundColor = ConsoleColor.DarkGray;


            _mymenu = new Menu("List Restaurants Alphabetically", "List Restaurants in Reverse Alphabetical", "Sort Restaurants From Best/Most Stars to Worst", "Sort Restaurants From Worst/Least Stars to Best ", "Show Only X and Up", "Exit");
            _mymenu.Title = "Come Eat At This Fancy Restaurant";
            _mymenu.Display();

            int choice = Validation.ValidateInt("Hey! How are we sorting Data Today?");
            switch (choice)
            {
                case 1:
                    AtoZ();
                    ContinueAgain();
                    break;
                case 2:
                    ZtoA();
                    ContinueAgain();
                    break;
                case 3:
                    Best();
                    ContinueAgain();
                    break;
                case 4:
                    Worst();
                    ContinueAgain();
                    break;
                case 5:
                    IDK();
                    break;
                case 6:
                    Console.WriteLine("Thanks for stopping by you better come back! or else!");
                    Environment.Exit(6);
                    break;
                default:
                    Console.WriteLine("Please enter valid input.");
                    Continue();
                    break;
            }
        }
        // These codes are coming soon.
        private void CardGame()
        {
            Console.WriteLine("There is nothing to see here. To be continued.");
        }
        private void Reviews()
        {
            Console.Clear();
            Database.Data11();
        }
        private void DinDin()
        {
            Console.Clear();
        }
        private void Tops()
        {
            Console.Clear();
        }
        private void AnimatedBar()
        {
            Console.Clear();
            Selection4();
        }
        private void SubMenu()
        {
            Console.Clear();
            Selection3();
        }
        private void FiveStarRating()
        {
            Console.Clear();
            Selection2();

        }
        private void OnlyFiveStar()
        {
            Console.Clear();
            Database.Data6();

        }
        private void IDK()
        {
            Console.Clear();
            SubMenu();

        }
        private void Worst()
        {
            Console.Clear();
            Database.Data5();
        }
        private void Best()
        {
            Console.Clear();
            Database.Data4();
        }
        private void AtoZ()
        {
            Console.Clear();
            Database.Data2();

        }
        private void ZtoA()
        {
            Console.Clear();
            Database.Data3();
        }
        private void Over4()
        {
            Console.Clear();
            Database.Data7();
        }
        private void Over3()
        {
            Console.Clear();
            Database.Data8();
        }
        private void OneAndOnly()
        {
            Console.Clear();
            Database.Data9();
        }
        private void Unrated()
        {
            Console.Clear();
            Database.Data10();
        }

        // This is an SQL Data Method Used to pull Data From Sql and convert to C#
        private void Data()
        {
            // MySQL Database Connection String
            string cs = @"server=127.0.0.1;userid=root;password=root;database=Sample Restaurant Database;port=8889";
            MySqlDataReader rdr;


            // Declare a MySQL Connection
            MySqlConnection conn = null;

            try
            {
                // Open a connection to MySQL
                conn = new MySqlConnection(cs);
                conn.Open();

                // Form SQL Statement
                string stm = "Select * FROM RestaurantProfiles";

                // Prepare SQL Statement
                MySqlCommand cmd = new MySqlCommand(stm, conn);

                rdr = cmd.ExecuteReader();
                // read is looking at data returned to us
                // When it reaches end of data it will break out of the while loop
                while (rdr.Read())
                {
                    string id = rdr["id"].ToString();
                    string restaurantName = rdr["RestaurantName"].ToString();
                    string address = rdr["Address"].ToString();
                    string phone = rdr["Phone"].ToString();
                    string hours = rdr["HoursOfOperation"].ToString();
                    string price = rdr["Price"].ToString();
                    string usa = rdr["USACityLocation"].ToString();
                    string cuisine = rdr["Cuisine"].ToString();
                    string food = rdr["FoodRating"].ToString();
                    string service = rdr["ServiceRating"].ToString();
                    string ambience = rdr["AmbienceRating"].ToString();
                    string value = rdr["ValueRating"].ToString();
                    string overallRating = rdr["OverallRating"].ToString();
                    string overallPossibleRating = rdr["OverallPossibleRating"].ToString();
                    // adding all of these strings to the restaurant list
                    _restaurant.Add(new Restaurant(id, restaurantName, address, phone, hours, price, usa, cuisine, food, service, ambience, value, overallRating, overallPossibleRating));

                }
            }
            catch (MySqlException ex)
            {
                Console.WriteLine("Error: {0}", ex.ToString());
            }
            finally
            {
                if (conn != null)
                {
                    conn.Close();
                }
            }

        }
        // This convert method is the first option on the menu that will run the 2 other methods.
        private void Convert()
        {
            Console.Clear();
            CreateJson();
            SaveToJSON();
            Console.WriteLine("Your SQL Data have been converted to your JSON File.");
        }
        // This method saves the data to the JSON file 
        private void SaveToJSON()
        {
            // it automatically dispose in a using block. Whatever happen in using stay in using.
            using (StreamWriter sw = new StreamWriter(_directory + _filename))
            {
                // Need an object, to help writing to a file
                sw.WriteLine("[");
                int counter = 0;
                for (int i = 0; i < _restaurant.Count; i++)
                {

                    sw.WriteLine("{");
                    sw.WriteLine($"\"id\":\"{_restaurant[i].id}\",");
                    sw.WriteLine($"\"RestaurantName\":\"{_restaurant[i].restaurantName}\",");
                    sw.WriteLine($"\"Address\":\"{_restaurant[i].Address}\",");
                    sw.WriteLine($"\"Phone\":\"{_restaurant[i].Phone}\",");
                    sw.WriteLine($"\"HouseOfOperation\":\"{_restaurant[i].HoursOfOperation}\",");
                    sw.WriteLine($"\"USACityLocation\":\"{_restaurant[i].USACityLocation}\",");
                    sw.WriteLine($"\"Cuisine\":\"{_restaurant[i].Cuisine}\",");
                    sw.WriteLine($"\"FoodRating\":\"{_restaurant[i].FoodRating}\",");
                    sw.WriteLine($"\"ServiceRating\":\"{_restaurant[i].ServiceRating}\",");
                    sw.WriteLine($"\"AmbienceRating\":\"{_restaurant[i].AmbienceRating}\",");
                    sw.WriteLine($"\"ValueRating\":\"{_restaurant[i].ValueRating}\",");
                    sw.WriteLine($"\"OverallRating\":\"{_restaurant[i].OverallRating}\",");
                    sw.WriteLine($"\"OverallPossibleRating\":\"{_restaurant[i].OverallPossibleRating}\"");

                    if (counter < _restaurant.Count - 1)
                    {
                        sw.WriteLine("},");
                    }
                    else
                    {
                        sw.WriteLine("}");
                    }
                    counter++;
                }
                sw.WriteLine("]");
            }
        }
        // This method will create your JSON file 
        private void CreateJson()
        {
            // Create the directory first before you can create file
            Directory.CreateDirectory(_directory);
            // If the does not exist this code will run and create it 
            if (!File.Exists(_directory + _filename))
            {

                File.Create(_directory + _filename).Dispose();
                Console.WriteLine("Your file has been created!");
            }
            else // if your file already exist this code runs
            {
                Console.WriteLine("Your file already exist.");
            }

        }
        private void BackToMenu()
        {
            Console.Clear();
            _mymenu = new Menu("List Restaurants Alphabetically", "List Restaurants in Reverse Alphabetical", "Sort Restaurants From Best/Most Stars to Worst", "Sort Restaurants From Worst/Least Stars to Best ", "Show Only X and Up", "Exit");
            //_mymenu.Title = "Come Eat At This Fancy Restaurant";
            _mymenu.Display();
            Selection2();

        }
        // This method will return back to the main menu of a menu
        private void Continue3()
        {
            Console.WriteLine("Press The Return Key To Go Back To The Main Menu...");
            Console.ReadKey();
            _mymenu.Display();
            Selection3();
        }
        // This method will return back to the main menu of a menu
        private void ContinueAgain()
        {
            Console.WriteLine("Press The Return Key To Go Back To The Main Menu...");
            Console.ReadKey();
            _mymenu.Display();
            Selection2();
        }
        // This method will return back to the main menu of a menu
        private void Continue()
        {
            Console.WriteLine("Press The Return Key To Go Back To The Main Menu...");
            Console.ReadKey();
            _mymenu.Display();
            Selection();
        }
    }
}